package com.example.testapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ShowAllDuty extends AppCompatActivity {

    String url = "http://52.221.213.45:5000/api/v1/app/dutyid/list";
    String checksum="$2y$12$BK6IrTsPB1eMc3liWuvvcuGoElFIyVNuFx3W3UAxVr9xmBKYsIuY6";
    private ListView listView;
    private ArrayList<String> animalList =new ArrayList<String>();
    private ProgressDialog dialog;
    private  String SelectedId;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all_duty);
        dialog = new ProgressDialog(this);
        listView = findViewById(R.id.AlldutyList);

        dialog.setMessage("Please wait.");
        dialog.show();
        getData();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {
                        SelectedId = animalList.get(i).toString();

                       Intent intent = new Intent(ShowAllDuty.this,ShowDutyDetails.class);
                       intent.putExtra("ID",SelectedId);
                       startActivity(intent);

            }
        });



    }


    private void getData()
    {
        RequestQueue mQueue = Volley.newRequestQueue(getApplicationContext());

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET,url, null,
                new Response.Listener<JSONArray>()
                {
                    @Override
                    public void onResponse(JSONArray response)
                    {
                        Log.d("TAG", response.toString());


                        for(int i=0;i<=response.length();i++)
                        {
                            try
                            {
                                animalList.add(response.get(i).toString());
                                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(ShowAllDuty.this, R.layout.dutylistrow, R.id.textView, animalList);
                                listView.setAdapter(arrayAdapter);
                                dialog.dismiss();
                            }
                            catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("TAG", error.getMessage(), error);
            }
        }) { //no semicolon or coma
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json");
                params.put("checksum",checksum);
                return params;
            }
        };
        mQueue.add(jsonArrayRequest);
    }
}
