package com.example.testapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ShowDutyDetails extends AppCompatActivity
{

    String checksum="";
    String checksum1="$2y$12$aN/C53yV6CBY2aRUbO9ZhecsbqIBVqZfQf6H05EkQNL/3gXaWC28G"; //4356
    String checksum2="$2y$12$XvYFQ35grhpFR.n9UxLnM.fnZBr5eTgGV7y4fxHvmF4xsfssvZxn."; //4357
    String checksum3="$2y$12$XVzJVMUZN.kUEzB82No1/OUb11DMxMve6d6zTdeuDr3HTWed6ky8W"; //4358
    String checksum4="$2y$12$mUFFB3wq/qiuospeYfw0YuE1HINJDDNHTmVEhKsaPFOIDYESQEvp."; //4359
    String url;
    private TextView id,assigned,state,type;
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_duty_details);

        id = findViewById(R.id.dutyID);
        assigned = findViewById(R.id.assigned);
        state = findViewById(R.id.state);
        type = findViewById(R.id.type);

        Intent intent = getIntent();
        String id = intent.getStringExtra("ID");

        if(id.equals("4356"))
        {
            checksum=checksum1;
        }
        else if(id.equals("4357"))
        {
            checksum=checksum2;
        }
        else if(id.equals("4358"))
        {
            checksum=checksum3;
        }
        else if(id.equals("4359"))
        {
            checksum=checksum4;
        }


         url = "http://52.221.213.45:5000/api/v1/app/duty/"+id;

        dialog = new ProgressDialog(this);
        dialog.setMessage("Please wait.");
        dialog.show();

        getDutyDetails();

    }

    private void getDutyDetails()
    {
        RequestQueue mQueue = Volley.newRequestQueue(getApplicationContext());

        JsonObjectRequest jsonobjectRequest = new JsonObjectRequest(Request.Method.GET,url, null,
                new Response.Listener<JSONObject>()
                {
                    @Override
                    public void onResponse(JSONObject response)
                    {
                        Log.d("TAG", response.toString());

                        try
                        {
                            id.setText(response.getString("id"));
                            assigned.setText(response.getString("assigned"));
                            state.setText(response.getString("state"));
                            type.setText(response.getString("type"));
                            dialog.dismiss();
                        }
                        catch (JSONException e) {

                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("TAG", error.getMessage(), error);
            }
        }) { //no semicolon or coma
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json");
                params.put("checksum",checksum);
                return params;
            }
        };
        mQueue.add(jsonobjectRequest);
    }
}
