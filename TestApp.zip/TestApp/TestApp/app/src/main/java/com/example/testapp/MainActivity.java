package com.example.testapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{


    private Button buttonDutyList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        buttonDutyList = findViewById(R.id.btnShowDutyList);

        buttonDutyList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

                Intent in = new Intent(MainActivity.this,ShowAllDuty.class);
                startActivity(in);

            }
        });



    }




}
